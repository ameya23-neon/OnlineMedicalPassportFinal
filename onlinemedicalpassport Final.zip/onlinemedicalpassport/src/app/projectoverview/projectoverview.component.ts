import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-projectoverview',
  templateUrl: './projectoverview.component.html',
  styleUrls: ['./projectoverview.component.css']
})
export class ProjectoverviewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
